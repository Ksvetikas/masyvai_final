import java.util.Arrays;
import java.util.Scanner;

public class masyvai15 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek turi buti prekiu:");
        int number = rd.nextInt();

        System.out.println("Iveskite kiek procentu prekes, kuriu kainos mazesnes nei prekiu vidurkis bus pabrangintos:");
        int p = rd.nextInt();

        int min = 0;

        int max = 1000;
        max++;

        double kainuSuma = 0;
        double kainuSuma2 = 0;
        double kainuVidurkis;
        double kainuVidurkisPoPabrangimo;

        double [] arrF = new double [number];

        for (int i = 0; i < arrF.length; i++) {
            arrF [i] = random (min, max);
            kainuSuma = kainuSuma + arrF [i];
        }

        kainuVidurkis = (double) Math.round((kainuSuma / arrF.length) * 100) / 100;;

        System.out.println("Pradiniu kainu vidurkis yra " + kainuVidurkis + "eur.");
        System.out.println("Visos pradines kainos:");
        System.out.print(Arrays.toString(arrF));
        System.out.println();
        for (int i = 0; i < arrF.length; i++) {
            if (arrF [i] < kainuVidurkis) {
                arrF [i] *= 1 + ((double)p / 100);
                arrF [i] = (double) Math.round(arrF [i] * 100) / 100;
            }
            kainuSuma2 = kainuSuma2 + arrF [i];
        }

        kainuVidurkisPoPabrangimo = (double) Math.round((kainuSuma2 / arrF.length) * 100) / 100;


        System.out.println("---------------");
        System.out.println("Kainu vidurkis po " + p + "% pabrangimo yra " + kainuVidurkisPoPabrangimo + "eur.");
        System.out.println("Visos prekiu kainos po pabrangimo:");
        System.out.print(Arrays.toString(arrF));

        rd.close();
    }

    public static double random(int min, int max) {

        double random = ((Math.random() * (max - min)) + min);
        return (double) Math.round(random * 100) / 100;
    }
}