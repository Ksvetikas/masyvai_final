import java.util.Arrays;
import java.util.Scanner;

public class masyvai25 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek elementu turi buti archyve:");
        int n = rd.nextInt();

        int min = -1000;

        int max = 1000;

        max++;
//        Si eilute itraukia maksimalia reiksmiu intervalo reiksme i intervala.

        int [] arrP = new int [n];
        int [] arrR = new int [n];

        for (int i = 0 ; i < arrP.length; i++) {

            arrP [i] = random (min, max);
            arrR [i] = arrP[i];
        }



        metodai.bubbleSort(arrP);

        metodai.sort(arrR);

        System.out.println("Masyvas arrP isrikiuotas didejimo tvarka naudojant Bubble Sort funkcija.");

        System.out.print(Arrays.toString(arrP));

        System.out.println();

        System.out.println("Masyvas arrR isrikiuotas didejimo tvarka naudojant Sort funkcija.");

        System.out.print(Arrays.toString(arrR));

        rd.close();
    }

    public static int random(int min, int max) {

        return (int) ((Math.random() * (max - min)) + min);
    }
}