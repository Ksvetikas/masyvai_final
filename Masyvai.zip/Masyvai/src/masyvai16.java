import java.util.Arrays;
import java.util.Scanner;

public class masyvai16 {


    public static void main(String[] args) {

        Scanner rd = new Scanner(System.in);

        System.out.println("Iveskite kiek masyve turi buti skaiciu:");
        int n = rd.nextInt();

        System.out.println("Iveskite kelinto masyvo elemento reiksme norite panaikinti:");
        int k = rd.nextInt();

        int min = 0;

        int max = 1000;

        max++;

        int [] arrG = new int [n];

        for (int i = 0; i < arrG.length; i++) {
            arrG [i] = metodai.random (min, max);
        }

        int [] arrH = new int [n - 1];

        for (int i = 0; i < arrG.length; i++) {
            if ((k - 1) == i){
                arrH [i] = arrG [i + 1];
            }else if ((k - 1) < i){
                if (i + 1 == arrG.length){
                    break;
                }else {
                    arrH[i] = arrG[i + 1];
                }
            }else{
                arrH [i] = arrG [i];
            }
        }
        System.out.print(Arrays.toString(arrG));
        System.out.println();
        System.out.println("Masyve esancio " + k + " elemento reiksme buvo panaikinta.");
        System.out.print(Arrays.toString(arrH));

        rd.close();
    }

//    public static int random(int min, int max) {
//
//        return (int) ((Math.random() * (max - min)) + min);
//    }
}